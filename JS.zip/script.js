document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const splashScreen = document.getElementById('splashScreen');
    const loginScreen = document.getElementById('loginScreen');
    const registrationScreen = document.getElementById('registrationScreen');
    const forgotPinScreen = document.getElementById('forgotPinScreen');
    const dashboardScreen = document.getElementById('dashboardScreen');
    const loadingProgress = document.getElementById('loadingProgress');
    const notification = document.getElementById('notification');
    
    // Navigation Buttons
    const goToRegister = document.getElementById('goToRegister');
    const backToLogin = document.getElementById('backToLogin');
    const backToWelcome = document.getElementById('backToWelcome');
    const backToLoginFromForgot = document.getElementById('backToLoginFromForgot');
    const forgotPin = document.getElementById('forgotPin');
    
    // Forms
    const loginForm = document.getElementById('loginForm');
    const registrationForm = document.getElementById('registrationForm');
    const forgotPinForm = document.getElementById('forgotPinForm');
    
    // Registration Step Elements
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');
    const sendOTPBtn = document.getElementById('sendOTP');
    const verifyOTPBtn = document.getElementById('verifyOTP');
    
    // OTP Elements
    const otpInputs = ['otp1', 'otp2', 'otp3', 'otp4', 'otp5', 'otp6'].map(id => document.getElementById(id));
    const otpTimer = document.getElementById('timer');
    
    // User Data Storage
    let users = JSON.parse(localStorage.getItem('bishash_users')) || {};
    let currentStep = 1;
    let registrationData = {};
    let generatedOTP = '';
    
    // Show Notification
    function showNotification(message, type = 'info') {
        notification.textContent = message;
        notification.className = 'notification';
        
        // Add type-based styling
        if (type === 'success') {
            notification.style.background = '#19be6b';
        } else if (type === 'error') {
            notification.style.background = '#ed3f14';
        } else {
            notification.style.background = '#333';
        }
        
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    // Start Splash Screen
    setTimeout(() => {
        loadingProgress.style.width = '100%';
    }, 100);
    
    // After 3 seconds, go to login screen
    setTimeout(() => {
        splashScreen.style.opacity = '0';
        
        setTimeout(() => {
            splashScreen.style.display = 'none';
            loginScreen.style.display = 'block';
            loginScreen.style.opacity = '0';
            
            setTimeout(() => {
                loginScreen.style.opacity = '1';
                loginScreen.style.transition = 'opacity 0.5s ease';
            }, 100);
            
            console.log("Bishash App loaded successfully!");
        }, 800);
    }, 3000);
    
    // Navigation Functions
    goToRegister.addEventListener('click', function(e) {
        e.preventDefault();
        loginScreen.style.display = 'none';
        registrationScreen.style.display = 'block';
        resetRegistrationForm();
    });
    
    backToLogin.addEventListener('click', function() {
        registrationScreen.style.display = 'none';
        loginScreen.style.display = 'block';
        resetRegistrationForm();
    });
    
    backToWelcome.addEventListener('click', function() {
        // This would go back to welcome screen if we had one
        // For now, just stay on login
        showNotification("স্বাগতম! লগইন বা রেজিস্ট্রেশন করুন", "info");
    });
    
    backToLoginFromForgot.addEventListener('click', function() {
        forgotPinScreen.style.display = 'none';
        loginScreen.style.display = 'block';
    });
    
    forgotPin.addEventListener('click', function(e) {
        e.preventDefault();
        loginScreen.style.display = 'none';
        forgotPinScreen.style.display = 'block';
    });
    
    // Toggle Password Visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    });
    
    // Login Form Submission
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const mobile = document.getElementById('loginMobile').value;
        const pin = document.getElementById('loginPin').value;
        
        // Validation
        if (!mobile || mobile.length !== 11) {
            showNotification("সঠিক মোবাইল নম্বর দিন (১১ অঙ্ক)", "error");
            return;
        }
        
        if (!pin || pin.length !== 6 || !/^\d+$/.test(pin)) {
            showNotification("৬-অঙ্কের পিন নম্বর দিন", "error");
            return;
        }
        
        // Check if user exists
        if (users[mobile]) {
            if (users[mobile].pin === pin) {
                // Successful login
                showNotification("লগইন সফল! স্বাগতম", "success");
                
                // Set current user
                localStorage.setItem('current_user', mobile);
                
                // Show user mobile in dashboard
                document.getElementById('userMobile').textContent = mobile;
                
                // Go to dashboard
                setTimeout(() => {
                    loginScreen.style.display = 'none';
                    dashboardScreen.style.display = 'block';
                }, 1500);
            } else {
                showNotification("পিন নম্বর ভুল", "error");
            }
        } else {
            showNotification("এই মোবাইল নম্বরে কোনো অ্যাকাউন্ট নেই", "error");
        }
    });
    
    // Registration Functions
    function resetRegistrationForm() {
        currentStep = 1;
        registrationData = {};
        generatedOTP = '';
        
        step1.style.display = 'block';
        step2.style.display = 'none';
        step3.style.display = 'none';
        
        // Reset progress indicator
        document.querySelectorAll('.progress-step').forEach(step => {
            step.classList.remove('active');
        });
        document.querySelector('.progress-step[data-step="1"]').classList.add('active');
        
        // Clear all inputs
        document.getElementById('regMobile').value = '';
        otpInputs.forEach(input => input.value = '');
        document.getElementById('regPin').value = '';
        document.getElementById('confirmPin').value = '';
    }
    
    function goToStep(step) {
        currentStep = step;
        
        // Hide all steps
        step1.style.display = 'none';
        step2.style.display = 'none';
        step3.style.display = 'none';
        
        // Show current step
        if (step === 1) {
            step1.style.display = 'block';
        } else if (step === 2) {
            step2.style.display = 'block';
        } else if (step === 3) {
            step3.style.display = 'block';
        }
        
        // Update progress indicator
        document.querySelectorAll('.progress-step').forEach(el => {
            el.classList.remove('active');
        });
        document.querySelector(`.progress-step[data-step="${step}"]`).classList.add('active');
    }
    
    // Generate OTP
    function generateOTP() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    }
    
    // Send OTP
    sendOTPBtn.addEventListener('click', function() {
        const mobile = document.getElementById('regMobile').value;
        
        if (!mobile || mobile.length !== 11) {
            showNotification("সঠিক মোবাইল নম্বর দিন (১১ অঙ্ক)", "error");
            return;
        }
        
        // Check if mobile already registered
        if (users[mobile]) {
            showNotification("এই নম্বরটি ইতিমধ্যে রেজিস্ট্র্ড", "error");
            return;
        }
        
        // Save mobile for registration
        registrationData.mobile = mobile;
        
        // Generate and save OTP
        generatedOTP = generateOTP();
        
        // In real app, this would send SMS
        console.log(`OTP for ${mobile}: ${generatedOTP}`);
        
        // Show success message
        showNotification(`OTP পাঠানো হয়েছে: ${generatedOTP}`, "success");
        
        // Go to OTP verification step
        goToStep(2);
        
        // Start OTP timer
        startOTPTimer();
    });
    
    // Start OTP Timer
    function startOTPTimer() {
        let timeLeft = 60;
        otpTimer.textContent = timeLeft;
        
        const timer = setInterval(() => {
            timeLeft--;
            otpTimer.textContent = timeLeft;
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                document.getElementById('otpTimer').innerHTML = 
                    '<a href="#" id="resendOTP" style="color: #e2136e; text-decoration: none;">OTP পুনরায় পাঠান</a>';
                
                document.getElementById('resendOTP').addEventListener('click', function(e) {
                    e.preventDefault();
                    generatedOTP = generateOTP();
                    console.log(`New OTP: ${generatedOTP}`);
                    showNotification(`নতুন OTP: ${generatedOTP}`, "success");
                    startOTPTimer();
                });
            }
        }, 1000);
    }
    
    // OTP Input Navigation
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', function() {
            if (this.value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
        });
        
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && !this.value && index > 0) {
                otpInputs[index - 1].focus();
            }
        });
    });
    
    // Verify OTP
    verifyOTPBtn.addEventListener('click', function() {
        const enteredOTP = otpInputs.map(input => input.value).join('');
        
        if (enteredOTP.length !== 6) {
            showNotification("সম্পূর্ণ OTP নম্বর দিন", "error");
            return;
        }
        
        if (enteredOTP === generatedOTP) {
            showNotification("OTP সফলভাবে যাচাই হয়েছে", "success");
            goToStep(3);
        } else {
            showNotification("ভুল OTP নম্বর", "error");
        }
    });
    
    // Registration Form Submission
    registrationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const pin = document.getElementById('regPin').value;
        const confirmPin = document.getElementById('confirmPin').value;
        
        // Validation
        if (!pin || pin.length !== 6 || !/^\d+$/.test(pin)) {
            showNotification("৬-অঙ্কের পিন নম্বর দিন", "error");
            return;
        }
        
        if (pin !== confirmPin) {
            showNotification("পিন নম্বর মিলছে না", "error");
            return;
        }
        
        // Save user
        users[registrationData.mobile] = {
            pin: pin,
            createdAt: new Date().toISOString()
        };
        
        // Save to localStorage
        localStorage.setItem('bishash_users', JSON.stringify(users));
        
        // Show success message
        showNotification("রেজিস্ট্রেশন সফল! এখন লগইন করুন", "success");
        
        // Go back to login
        setTimeout(() => {
            registrationScreen.style.display = 'none';
            loginScreen.style.display = 'block';
            resetRegistrationForm();
        }, 2000);
    });
    
    // Forgot PIN Form
    forgotPinForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const mobile = document.getElementById('forgotMobile').value;
        
        if (!mobile || mobile.length !== 11) {
            showNotification("সঠিক মোবাইল নম্বর দিন", "error");
            return;
        }
        
        // Check if user exists
        if (users[mobile]) {
            // In real app, send OTP for reset
            generatedOTP = generateOTP();
            console.log(`Reset OTP for ${mobile}: ${generatedOTP}`);
            
            showNotification(`পিন রিসেট OTP পাঠানো হয়েছে: ${generatedOTP}`, "success");
            
            // Go to OTP verification (would be separate screen in real app)
            setTimeout(() => {
                forgotPinScreen.style.display = 'none';
                loginScreen.style.display = 'block';
                showNotification("OTP যাচাই করে নতুন পিন সেট করুন", "info");
            }, 2000);
        } else {
            showNotification("এই নম্বরে কোনো অ্যাকাউন্ট নেই", "error");
        }
    });
    
    // Logout Function
    document.getElementById('logoutBtn').addEventListener('click', function() {
        localStorage.removeItem('current_user');
        dashboardScreen.style.display = 'none';
        loginScreen.style.display = 'block';
        showNotification("সফলভাবে লগআউট হয়েছে", "info");
    });
    
    // Dashboard Action Buttons
    document.querySelectorAll('.action-btn').forEach(button => {
        button.addEventListener('click', function() {
            const action = this.querySelector('span').textContent;
            showNotification(`${action} ফিচারটি শীঘ্রই আসছে!`, "info");
        });
    });
    
    // Mobile number input validation
    document.querySelectorAll('input[type="tel"]').forEach(input => {
        input.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '').slice(0, 11);
        });
    });
    
    // PIN input validation
    document.querySelectorAll('input[type="password"][maxlength="6"]').forEach(input => {
        input.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '').slice(0, 6);
        });
    });
    
    console.log("Bishash App with Login System loaded!");
});